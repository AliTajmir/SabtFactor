﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
   public static class Get_Information
    {
        public static List<T> GetList<T>(List<T> p)
        {
            List<T> items = p;
            return items;

        }
    }
}
